imspline <- function(x,y,pos=max(x),thred=0.1,ifplot=F,ifscale=T){
  #setup
  # x <- i$hours
  # y <- i$value
  # pos <- i.base$hours
  # thred <- 0.1
  # ifplot <- T
  # ifscale <- T
  #process
  pos <- ceiling(pos)
  if(ifscale){
    x <- x/pos * 100
    pos <- 100
  }
  #model
  if(length(x)==0){
    return(rep(NA,pos+1))
  }
  if(length(x)==1){
    return(rep(x,pos+1))
  }
  f <- splinefun(x,y,method='monoH.FC')
  f <- f(0:pos)
  f <- ifelse(f>max(y)*(1+thred),max(y)*(1+thred),f)
  f <- ifelse(f<min(y)*(1-thred),min(y)*(1-thred),f)
  if(ifplot){
    plot((0:pos),f,type='l',col=2)
    lines(x,y,type='p')
  }
  f
}
imfourier <- function(x,y,pos=max(x),ifplot=F){
  y <- y[order(x)]
  x <- x[order(x)]
  pos <- ceiling(pos)
  fbasis <- create.fourier.basis(range(x)/pos,length(x)*2-1)
  phi <- eval.basis(x/pos,fbasis)
  fcoef <- myinv(t(phi)%*%phi)%*%t(phi)%*%cbind(x/pos)
  phi2 <- eval.basis((0:pos)/pos,fbasis)
  f <- phi2 %*% fcoef
  if(ifplot){
    plot((0:pos)/pos,f,type='l',col=2)
    lines(x/pos,y,type='p')
  }
  f
}
imrate <- function(pidi,ifscale=T){
  #setup
  i <- filter(rate,pid==pidi) %>% arrange(rate)
  pos <- filter(base,pid==pidi)$hours
  #process
  pos <- ceiling(pos)
  if(ifscale){
    i <- i %>% mutate(hour1=hour1/pos*100+1,hour2=hour2/pos*100+1)
    pos <- 100
  }
  #model
  out <- rep(0,length=pos+1)
  if(nrow(i)==0){
    return(out)
  }
  for(j in 1:nrow(i)){
    out[(floor(i$hour1[j])*(i$hour1[j]>0)):min(ceiling(i$hour2[j]),(pos+1))] <- i$rate[j]
  }
  out <- out[1:(pos+1)]
  return(out)
}
imrange <- function(i,pos,ifscale=T){
  #setup
  # i <- i
  # pos <- i.base$hours
  # ifscale <- T
  #process
  pos <- ceiling(pos)
  if(ifscale){
    i <- i %>% mutate(hour1=hour1/pos*100+1,hour2=hour2/pos*100+1)
    pos <- 100
  }
  #model
  out <- rep(0,length=pos+1)
  if(nrow(i)==0){
    return(out)
  }
  for(j in 1:nrow(i)){
    out[(floor(i$hour1[j])*(i$hour1[j]>0)):min(ceiling(i$hour2[j]),(pos+1))] <- 1
  }
  out <- out[1:(pos+1)]
  return(out)
}
imlm <- function(y,x){
  sel.lm <- coef(lm(y~x))
  sel.lm[1]+sel.lm[2]*x
}
myinv<-function(A){
  A_svd<-fast.svd(A)
  if(length(A_svd$d)==1){
    A_inv<-A_svd$v%*%as.matrix(1/A_svd$d)%*%t(A_svd$u)
  }else{
    A_inv<-A_svd$v%*%diag(1/A_svd$d)%*%t(A_svd$u)
  }
  return(A_inv)
}
imcor <- function(i,j,test=F){
  sel <- !(is.na(i))&!(is.na(j))
  if(test){
    cor.test(i[sel],j[sel])$p.value
  } else {
    cor(i[sel],j[sel])
  }
}
imlms <- function(y,xs){
  temp <- apply(xs,2,function(x){
    imlm(y,x)
  })
  rowMeans(temp,na.rm=T)
}
qpca <- function(A,rank=0){
  # A <- scale(A)
  A.svd <- svd(A)
  if(rank==0){
    d <- A.svd$d
  } else {
    d <- A.svd$d-A.svd$d[min(rank+1,nrow(A),ncol(A))]
  }
  d <- d[d > 1e-10]
  r <- length(d)
  prop <- d^2; prop <- cumsum(prop/sum(prop))
  d <- diag(d,length(d),length(d))
  u <- A.svd$u[,1:r,drop=F]
  v <- A.svd$v[,1:r,drop=F]
  x <- u%*%sqrt(d)
  y <- sqrt(d)%*%t(v)
  z <- x %*% y
  rlt <- list(rank=r,X=x,Y=y,Z=x%*%y,prop=prop)
  return(rlt)
}
jm <- function(pidi){
  print(k<<-k+1)
  trate <- imrate(pidi)
  i.base <- filter(base,pid==pidi)
  i.idx <- filter(idx,pid==pidi)
  i.idx <- sapply(tag.idx,function(i){
    i <- filter(i.idx,item==i) %>%
      group_by(pid,hours,item) %>% summarise(value=mean(value))
    imspline(i$hours,i$value,i.base$hours,0.1,F,T)
  })
  i.exe <- filter(fexe,pid==pidi)
  i.exe <- sapply(tag.exe,function(i){
    i <- filter(i.exe,item==i)
    imrange(i,i.base$hours)
  })
  rlt <- data.table(pid=pidi,com=i.base$com_or_not,diag_no=i.base$diag_no,
                    orate=i.base$orate,hours=i.base$hours,
                    i.idx,i.exe,trate=trate)
  rlt
}
ret <- function(x,ret=0.3){
  x.ori <- x
  for(i in 2:length(x)){
    x[i] <- x[i-1] * ret + x[i]
  }
  x
}
ret2 <- function(x,ret2=0.3){
  x1 <- x
  x2 <- ret(x[length(x):1],ret2)[length(x):1]+ret(x,ret2)
  # x2 * max(x1)/max(x2)
  x2 <- x2 * sum(x1)/sum(x2)
  sel <- rowMeans(cbind(lag(x1),x1,lead(x1)),na.rm=T)==x1
  x2[sel] <- x1[sel]
  x2
}
area2 <- function(pidi){
  # print(i<<-i+1)
  # print(pidi)
  x <- filter(out,pid==pidi)$exp_rate
  x <- (x==0)*0.505 + (x==1)*0.261 + (x==2) * 0.114
  x.hour <- floor(filter(base,pid==pidi)$hours*100)
  x.rate <- filter(base,pid==pidi)$orate
  x.int <- filter(out,pid==pidi)$day
  f.x <- x.int*6
  f.y <- ret2(x)
  # plot(f.x,f.y,type='l')
  f <- splinefun(f.x,f.y)
  f <- f(s <- (0:ceiling(x.hour/100)))
  f <- ifelse(f>0.505,0.505,ifelse(f<0.114,0.114,f))
  # lines(s,f,type='l',col=2)
  f
}
